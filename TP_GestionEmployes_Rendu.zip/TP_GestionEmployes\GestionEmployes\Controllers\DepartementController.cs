using GestionEmployes.Data;
using GestionEmployes.Models;
using Microsoft.AspNetCore.Mvc;

namespace GestionEmployes.Controllers
{
    public class DepartementController : Controller
    {
        private readonly GestionDbContext _context;

        public DepartementController(GestionDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var Result = _context.Departements.OrderBy(x => x.NomDepartement).ToList();
            ViewBag.NbEmployes = _context.Employes
                .GroupBy(e => e.DepartementId)
                .Select(g => new { g.Key, Nb = g.Count() })
                .ToDictionary(x => x.Key, x => x.Nb);
            return View(Result);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Departement model)
        {
            if (ModelState.IsValid)
            {
                _context.Departements.Add(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(model);
        }

        public IActionResult Edit(int? Id)
        {
            var Resultat = _context.Departements.Find(Id);
            if (Resultat == null) return NotFound();
            return View("Create", Resultat);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Departement model)
        {
            if (ModelState.IsValid)
            {
                _context.Departements.Update(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View("Create", model);
        }

        public IActionResult Delete(int? Id)
        {
            var Resultat = _context.Departements.Find(Id);
            if (Resultat != null)
            {
                // On refuse de supprimer un département qui contient encore des employés
                if (_context.Employes.Any(e => e.DepartementId == Id))
                {
                    TempData["Erreur"] = $"Impossible de supprimer le département « {Resultat.NomDepartement} » : il contient encore des employés.";
                    return RedirectToAction(nameof(Index));
                }

                _context.Departements.Remove(Resultat);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
