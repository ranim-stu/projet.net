using GestionEmployes.Data;
using GestionEmployes.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GestionEmployes.Controllers
{
    public class EmployeController : Controller
    {
        private readonly GestionDbContext _context;

        public EmployeController(GestionDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            // Inclure le département afin d'afficher son nom, et classer les employés par nom
            var Result = _context.Employes.Include(x => x.Departement).OrderBy(x => x.NomEmploye).ToList();
            return View(Result);
        }

        public IActionResult Create()
        {
            ViewBag.Departements = _context.Departements.OrderBy(x => x.NomDepartement).ToList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Employe model)
        {
            ChargerImage(model);

            if (ModelState.IsValid)
            {
                _context.Employes.Add(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            ViewBag.Departements = _context.Departements.OrderBy(x => x.NomDepartement).ToList();
            return View(model);
        }

        public IActionResult Edit(int? Id)
        {
            // Récupérer la liste des départements, chercher l'employé sélectionné et l'afficher dans la vue Create
            ViewBag.Departements = _context.Departements.OrderBy(x => x.NomDepartement).ToList();
            var Resultat = _context.Employes.Find(Id);
            if (Resultat == null) return NotFound();
            return View("Create", Resultat);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Employe model)
        {
            ChargerImage(model);

            if (ModelState.IsValid) // si toutes les données saisies sont correctes
            {
                _context.Employes.Update(model); // mettre à jour l'employé sélectionné
                _context.SaveChanges();          // reporter la mise à jour vers la base de données
                return RedirectToAction(nameof(Index)); // afficher la page Index
            }

            ViewBag.Departements = _context.Departements.OrderBy(x => x.NomDepartement).ToList();
            return View("Create", model);
        }

        public IActionResult Delete(int? Id)
        {
            var Resultat = _context.Employes.Find(Id);
            if (Resultat != null)
            {
                _context.Employes.Remove(Resultat);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        private void ChargerImage(Employe model)
        {
            var file = HttpContext.Request.Form.Files;

            if (file.Count() > 0)
            {
                // charger l'image si le fichier est chargé
                string NomImage = Guid.NewGuid().ToString() + Path.GetExtension(file[0].FileName);
                using var fileStream = new FileStream(Path.Combine(@"wwwroot/", "Images", NomImage), FileMode.Create);
                file[0].CopyTo(fileStream);
                model.UserImage = NomImage;
            }
            else if (model.UserImage == null && model.EmployeId == 0)
            {
                // ne pas charger l'image mais créer un employé
                model.UserImage = "DefaultImage.jpg";
            }
            // sinon (édition sans nouvelle image) : on garde model.UserImage envoyé par le champ caché
        }
    }
}
