﻿using GestionEmployes.Models;
using Microsoft.EntityFrameworkCore;

namespace GestionEmployes.Data
{
    public class GestionDbContext : DbContext
    {
        public GestionDbContext(DbContextOptions<GestionDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            /* modelBuilder.Entity<Employe>().ToTable("Employes", "HR"); cette ligne est équivalente à [Table("Employes", Schema = "HR")] */

            // Remplir les tables par des enregistrements
            modelBuilder.Entity<Departement>().HasData(
                new Departement { DepartementId = 1, NomDepartement = "informatique" },
                new Departement { DepartementId = 2, NomDepartement = "commerce" },
                new Departement { DepartementId = 3, NomDepartement = "gestion" },
                new Departement { DepartementId = 4, NomDepartement = "réseaux" }
            );

            modelBuilder.Entity<Employe>().HasData(
                new Employe { EmployeId = 1, NomEmploye = "SABRI", UserImage = "DefaultImage.jpg", DateNaissance = new DateTime(2000, 1, 1), Salaire = 14000, DateEmbauche = new DateTime(2020, 1, 1), NationalId = "12345", DepartementId = 1 },
                new Employe { EmployeId = 2, NomEmploye = "IDRISSI", UserImage = "DefaultImage.jpg", DateNaissance = new DateTime(1999, 2, 2), Salaire = 13000, DateEmbauche = new DateTime(2018, 2, 2), NationalId = "23456", DepartementId = 2 },
                new Employe { EmployeId = 3, NomEmploye = "BENNANI", UserImage = "DefaultImage.jpg", DateNaissance = new DateTime(1998, 3, 3), Salaire = 16000, DateEmbauche = new DateTime(2010, 3, 3), NationalId = "34567", DepartementId = 3 },
                new Employe { EmployeId = 4, NomEmploye = "SEMMAR", UserImage = "DefaultImage.jpg", DateNaissance = new DateTime(1984, 4, 4), Salaire = 17000, DateEmbauche = new DateTime(2006, 5, 4), NationalId = "45678", DepartementId = 1 }
            );
        }

        public DbSet<Departement> Departements { get; set; } = null!;
        public DbSet<Employe> Employes { get; set; } = null!;
    }
}
