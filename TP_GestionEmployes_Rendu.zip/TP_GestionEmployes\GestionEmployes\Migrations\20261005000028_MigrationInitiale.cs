﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GestionEmployes.Migrations
{
    public partial class MigrationInitiale : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "HR");

            migrationBuilder.CreateTable(
                name: "Departements",
                schema: "HR",
                columns: table => new
                {
                    DepartementId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomDepartement = table.Column<string>(type: "varchar(200)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Departements", x => x.DepartementId);
                });

            migrationBuilder.CreateTable(
                name: "Employes",
                schema: "HR",
                columns: table => new
                {
                    EmployeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NomEmploye = table.Column<string>(type: "varchar(200)", nullable: false),
                    UserImage = table.Column<string>(type: "varchar(200)", nullable: true),
                    DateNaissance = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Salaire = table.Column<decimal>(type: "decimal(12,2)", nullable: false),
                    DateEmbauche = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NationalId = table.Column<string>(type: "varchar(5)", maxLength: 5, nullable: false),
                    DepartementId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employes", x => x.EmployeId);
                    table.ForeignKey(
                        name: "FK_Employes_Departements_DepartementId",
                        column: x => x.DepartementId,
                        principalSchema: "HR",
                        principalTable: "Departements",
                        principalColumn: "DepartementId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                schema: "HR",
                table: "Departements",
                columns: new[] { "DepartementId", "NomDepartement" },
                values: new object[,]
                {
                    { 1, "informatique" },
                    { 2, "commerce" },
                    { 3, "gestion" },
                    { 4, "réseaux" }
                });

            migrationBuilder.InsertData(
                schema: "HR",
                table: "Employes",
                columns: new[] { "EmployeId", "DateEmbauche", "DateNaissance", "DepartementId", "NationalId", "NomEmploye", "Salaire", "UserImage" },
                values: new object[,]
                {
                    { 1, new DateTime(2020, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2000, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, "12345", "SABRI", 14000m, "DefaultImage.jpg" },
                    { 2, new DateTime(2018, 2, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(1999, 2, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), 2, "23456", "IDRISSI", 13000m, "DefaultImage.jpg" },
                    { 3, new DateTime(2010, 3, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(1998, 3, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), 3, "34567", "BENNANI", 16000m, "DefaultImage.jpg" },
                    { 4, new DateTime(2006, 5, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(1984, 4, 4, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, "45678", "SEMMAR", 17000m, "DefaultImage.jpg" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Employes_DepartementId",
                schema: "HR",
                table: "Employes",
                column: "DepartementId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employes",
                schema: "HR");

            migrationBuilder.DropTable(
                name: "Departements",
                schema: "HR");
        }
    }
}
