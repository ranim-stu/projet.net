using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GestionEmployes.Models
{
    [Table("Departements", Schema = "HR")]
    public class Departement
    {
        [Key]
        [Display(Name = "ID")]
        public int DepartementId { get; set; }

        [Required(ErrorMessage = "Le nom du département est obligatoire")]
        [Display(Name = "Nom Departement")]
        [Column(TypeName = "varchar(200)")]
        public string NomDepartement { get; set; } = string.Empty;
    }
}
