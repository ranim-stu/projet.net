using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GestionEmployes.Models
{
    [Table("Employes", Schema = "HR")]
    public class Employe
    {
        [Key]
        [Display(Name = "ID")]
        public int EmployeId { get; set; }

        [Required(ErrorMessage = "Le nom est obligatoire")]
        [Display(Name = "Nom")]
        [Column(TypeName = "varchar(200)")]
        public string NomEmploye { get; set; } = string.Empty;

        [Display(Name = "Image User")]
        [Column(TypeName = "varchar(200)")]
        public string? UserImage { get; set; }

        [Display(Name = "Date Naissance")]
        [DataType(DataType.Date)]
        public DateTime DateNaissance { get; set; }

        [Display(Name = "Salaire")]
        [Column(TypeName = "decimal(12,2)")]
        public decimal Salaire { get; set; }

        [Display(Name = "Date Embauche")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        public DateTime DateEmbauche { get; set; }

        [Required(ErrorMessage = "Le National ID est obligatoire")]
        [Display(Name = "National ID")]
        [MaxLength(5)]
        [MinLength(5, ErrorMessage = "Le National ID doit contenir 5 caractères")]
        [Column(TypeName = "varchar(5)")]
        public string NationalId { get; set; } = string.Empty;

        [Display(Name = "Departement")]
        public int DepartementId { get; set; }

        public Departement? Departement { get; set; }
    }
}
