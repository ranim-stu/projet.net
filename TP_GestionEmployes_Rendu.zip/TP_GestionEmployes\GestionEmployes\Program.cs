using GestionEmployes.Data;
using Microsoft.EntityFrameworkCore;

namespace GestionEmployes;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.
        builder.Services.AddControllersWithViews();
        builder.Services.AddDbContext<GestionDbContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("ConnectionDb")));

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
        }
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthorization();

        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Employe}/{action=Index}/{id?}");

        app.Run();
    }
}
