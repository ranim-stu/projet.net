using GestionProduits.Data;
using GestionProduits.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace GestionProduits.Pages.Categories;

public class DeleteModel : PageModel
{
    private readonly AppDbContext _context;
    public DeleteModel(AppDbContext context) => _context = context;

    public Categorie Categorie { get; set; } = default!;
    public int NombreProduits { get; set; }
    public string? MessageErreur { get; set; }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        return await ChargerCategorie(id) ? Page() : NotFound();
    }

    public async Task<IActionResult> OnPostAsync(int id)
    {
        if (!await ChargerCategorie(id)) return RedirectToPage("Index");

        // DeleteBehavior.Restrict : la base refuse la suppression si des produits y sont liés
        if (NombreProduits > 0)
        {
            MessageErreur = "Impossible de supprimer cette catégorie : elle contient encore des produits.";
            return Page();
        }

        _context.Categories.Remove(Categorie);
        await _context.SaveChangesAsync();
        return RedirectToPage("Index");
    }

    private async Task<bool> ChargerCategorie(int id)
    {
        var categorie = await _context.Categories.FindAsync(id);
        if (categorie == null) return false;

        Categorie = categorie;
        NombreProduits = await _context.Produits.CountAsync(p => p.CategorieId == id);
        return true;
    }
}
