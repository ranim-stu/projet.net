# Réponses aux questions – TP Gestion de produits

## Question 1 : Clé étrangère de la table `Produits` et comportement à la suppression

La clé étrangère de la table `Produits` est la colonne **`CategorieId`** (contrainte `FK_Produits_Categories_CategorieId`), qui référence la colonne `Id` de la table `Categories`.

EF Core l'a détectée **par convention** : la propriété `CategorieId` porte le nom de la navigation `Categorie` suivi de `Id`, et la classe `Categorie` possède une collection `Produits`.

Comme `CategorieId` est de type `int` (non nullable), la relation est **obligatoire**. Pour une relation obligatoire, EF Core choisit par défaut **`ON DELETE CASCADE`** (`onDelete: ReferentialAction.Cascade` dans la migration `InitialCreate`) : supprimer une catégorie supprime automatiquement tous les produits qui lui sont rattachés.

> Ce comportement a ensuite été remplacé par `DeleteBehavior.Restrict` (exercice 3, migration `CategorieRestrict`) : SQL Server refuse alors de supprimer une catégorie qui contient encore des produits.

## Question 2 : Contenu du dossier `Migrations` et table `__EFMigrationsHistory`

Le dossier `Migrations` contient :

- **Un fichier `<horodatage>_<Nom>.cs` par migration** (ex. `20261004232018_InitialCreate.cs`, `20261004232131_AjoutStock.cs`). Il contient une méthode **`Up()`**, qui applique les changements au schéma (`CreateTable`, `AddColumn`, `InsertData`…), et une méthode **`Down()`**, qui les annule.
- **Un fichier `<horodatage>_<Nom>.Designer.cs`** par migration : il contient l'état complet du modèle au moment de cette migration (métadonnées utilisées par EF).
- **`AppDbContextModelSnapshot.cs`** : un instantané du modèle actuel. EF le compare au modèle C# pour calculer les différences lors du prochain `migrations add`.

Après l'étape 24 (`dotnet ef migrations add AjoutStock` puis `dotnet ef database update`) :

1. EF lit la table `__EFMigrationsHistory` pour savoir quelles migrations ont déjà été appliquées (ici `InitialCreate`).
2. Il exécute uniquement la méthode `Up()` de la nouvelle migration `AjoutStock`, soit :
   `ALTER TABLE [Produits] ADD [Stock] int NOT NULL DEFAULT 0;`
   (les produits existants reçoivent un stock de 0).
3. Il **ajoute une nouvelle ligne** dans `__EFMigrationsHistory` avec `MigrationId = '20261004232131_AjoutStock'` et `ProductVersion = '8.0.31'`.

La table contient donc deux lignes après l'étape 24 (`InitialCreate` et `AjoutStock`), puis trois après l'exercice 3 (`CategorieRestrict`). C'est grâce à cette table qu'une migration n'est jamais appliquée deux fois.
